<?php require 'header.php'; ?>

<center>
	<h1>Sorry, This page is down for maintenance.</h1>
</center>

<?php require 'footer.php'; ?>